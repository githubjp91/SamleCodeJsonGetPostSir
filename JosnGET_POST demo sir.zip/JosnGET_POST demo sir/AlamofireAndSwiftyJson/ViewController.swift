//
//  ViewController.swift
//  AlamofireAndSwiftyJson
//
//  Created by agilemac-74 on 11/05/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tblJSON: UITableView!
    
    var arrRes = [[String:AnyObject]]() //Array of dictionary
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        Alamofire.request("http://api.androidhive.info/contacts/").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)

                if let resData = swiftyJsonVar["contacts"].arrayObject {
                    self.arrRes = resData as! [[String:AnyObject]]
                }
                if self.arrRes.count > 0 {
                    self.tblJSON.reloadData()
                }
            }
        }
        
        
        
      
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrRes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "jsonCell")!
        var dict = arrRes[(indexPath as NSIndexPath).row]
        cell.textLabel?.text = dict["name"] as? String
        cell.detailTextLabel?.text = dict["email"] as? String
        return cell

    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
}

/*====================post metho======================


let urlString:String = "http://202.131.117.90:8009/GoSolar/index.php/api/getReferred_users"
//let params:String = "{\"user_id\":1,\"list_type\":\"sales\",\"limit\":10,\"page\":1}"
let parameters: Parameters = ["referred_user_details": "params"]

print("==================API========================")
print("URL:\(urlString)")
print("Parameters:\(parameters)")
print("=============================================")

Alamofire.request(urlString, method: .post, parameters: parameters, encoding: JSONEncoding.default)
    .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
        print("Progress: \(progress.fractionCompleted)")
    }
    .validate { request, response, data in
        // Custom evaluation closure now includes data (allows you to parse data to dig out error messages if necessary)
        return .success
    }
    .responseJSON { response in
        debugPrint(response)
}
*/
